﻿///Jakob Heinz
///Wednesday April 18, 2018
///scrabble word list generator
///
///Create a list of words from an online source,
///and remove all words longer than 7 characters.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace U3_ReadFile_Jakob
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            ///webClient to get info

            System.Net.WebClient webClient = new System.Net.WebClient();
            string url = "http://darcy.rsgc.on.ca/ACES/ICS4U/SourceCode/Words.txt"; ///defines url
            webClient.BaseAddress = url;
            System.IO.StreamReader streamReader = new System.IO.StreamReader(webClient.OpenRead(url));
            System.IO.StreamWriter streamWriter = new System.IO.StreamWriter("words.txt");

            try
            {
                while (!streamReader.EndOfStream)
                {
                    string word = streamReader.ReadLine();
                    if (word.Length < 8)
                    {
                        streamWriter.Write(word.ToUpper() + "\r" + "\n"); /// adds words to txt file and changes them to all uppercase
                    }
                }
                streamWriter.Flush();
                streamWriter.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("you done goofed" + ex);
            }
        }
    }
}
